# Messi

Messi is the best player in the world

Neymar e o melhor amigo do messi
Messi neymar e suarez formaram o melhor trio de ataque da historia do futebol